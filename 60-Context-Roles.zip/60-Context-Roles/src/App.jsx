import { AuthProvider } from './components/AuthContext.jsx';
import Router from './components/Router.jsx'; // Vagy App tartalom
import Navigation from './components/Navbar.jsx';


const App = () => (
  <AuthProvider>
    <Navigation />
    <Router />
  </AuthProvider>
);

export default App;