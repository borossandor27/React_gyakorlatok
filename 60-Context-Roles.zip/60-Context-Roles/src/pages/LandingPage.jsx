const LandingPage = () => {
    return (    
        <div>
            <h1>Üdvözöljük az alkalmazásunkban!</h1>
            <p>Ez az induló oldal, amely minden felhasználó számára elérhető.</p>
        </div>
    );
}

export default LandingPage;