const UserProfile = () => {
    return (    
        <div>
            <h1>Felhasználói Profil</h1>
            <p>Ez a felhasználói profil oldal, amely csak bejelentkezett felhasználók számára érhető el.</p>
        </div>
    );
}   

export default UserProfile;