import React, { createContext, useState, useContext } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  // Kezdeti állapot: vendég
  const [user, setUser] = useState({ 
    isLoggedIn: false, 
    role: 'guest' 
  });

  // Készítesz egy bejelentkezési funkciót, ami beállítja a szerepkört
  const login = (userData) => {
    // ... (API hívás a tokenért/adatokért)
    setUser({
      isLoggedIn: true,
      role: userData.role // Pl. 'admin' vagy 'registered'
    });
  };

  const logout = () => {
    setUser({ isLoggedIn: false, role: 'guest' });
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);