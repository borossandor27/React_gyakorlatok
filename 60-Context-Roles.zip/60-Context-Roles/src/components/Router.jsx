// Router.jsx
import { Routes, Route } from 'react-router-dom';
import RoleBasedRoute from './RoleBasedRoute';
import AdminDashboard from '../pages/AdminDashboard';
import UserProfile from '../pages/UserProfile';
import LandingPage from '../pages/LandingPage';

const Router = () => (
  <Routes>
    {/* Mindenki számára elérhető */}
    <Route path="/" element={<LandingPage />} />
    
    {/* Védett útvonalak */}
    <Route element={<RoleBasedRoute expectedRoles={['admin']} />}>
      {/* Csak 'admin' szerepkörűek számára elérhető */}
      <Route path="/admin" element={<AdminDashboard />} />
    </Route>

    <Route element={<RoleBasedRoute expectedRoles={['admin', 'registered']} />}>
      {/* 'admin' és 'registered' szerepkörűek számára elérhető */}
      <Route path="/profile" element={<UserProfile />} />
    </Route>

  </Routes>
);

export default Router;